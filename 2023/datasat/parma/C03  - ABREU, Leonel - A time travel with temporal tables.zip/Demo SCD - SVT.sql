ALTER TABLE DimProduct
ADD
HistoryModelName	NVARCHAR(50)
,HistorySizeRange	NVARCHAR(50)
,HistorySizeUnitMeasureCode	NCHAR(3)

UPDATE DimProduct
SET HistoryModelName = ModelName
,HistorySizeRange = SizeRange
,HistorySizeUnitMeasureCode	= SizeUnitMeasureCode

ALTER TABLE DimProduct
ADD
	ValidFrom DATETIME2 GENERATED ALWAYS AS ROW START HIDDEN CONSTRAINT DF_Product_ValidFrom DEFAULT SYSUTCDATETIME()
	,ValidTo DATETIME2 GENERATED ALWAYS AS ROW END HIDDEN CONSTRAINT DF_Product_ValidTo DEFAULT CONVERT(DATETIME2, '9999-12-31 23:59:59.9999999')
	,PERIOD FOR SYSTEM_TIME (ValidFrom, ValidTo);
GO
ALTER TABLE DimProduct
SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.DimProductHistory));

SELECT	*
FROM	DimProduct
FOR SYSTEM_TIME ALL 
WHERE	ProductKey = 214

SELECT	*
FROM	DimProduct
WHERE	ProductAlternateKey = 'HL-U509-R'
AND		CONVERT(DATE, (StartDate)) = CONVERT(DATE, (GETDATE()))
UNION
SELECT	*
FROM	DimProduct
WHERE	ProductAlternateKey = 'HL-U509'
AND		CONVERT(DATE, (StartDate)) = CONVERT(DATE, (GETDATE()))

