-- Cambiar SizeUnitMeasureCode, ModelName, SizeRange
UPDATE	Playground.dbo.NewProductsCatalog
SET		SizeUnitMeasureCode = 'in'
		,SizeRange = '6 - 7'
		,ModelName = 'Sport-2022-R'
		
WHERE	ProductKey = 214

UPDATE	Playground.dbo.NewProductsCatalog
SET		SizeUnitMeasureCode = 'in'
		,SizeRange = '7 - 8'
		,ModelName = 'Sport-2022-B'
WHERE	ProductKey = 217

SELECT	[ProductKey]
		,CONVERT(INT, CONVERT(VARCHAR, DATEADD(MONTH, 3, [OrderDate]), 112)) [OrderDateKey]
		,CONVERT(INT, CONVERT(VARCHAR, DATEADD(MONTH, 3, [DueDate]), 112)) [DueDateKey]
		,CONVERT(INT, CONVERT(VARCHAR, DATEADD(MONTH, 3, [ShipDate]), 112)) [ShipDateKey]
		,[CustomerKey]
		,[PromotionKey]
		,[CurrencyKey]
		,[SalesTerritoryKey]
		,[SalesOrderNumber]
		,[SalesOrderLineNumber] + 10 [SalesOrderLineNumber]
		,[RevisionNumber]
		,[OrderQuantity]
		,[UnitPrice]
		,[ExtendedAmount]
		,5 [UnitPriceDiscountPct]
		,([UnitPrice] * 5 / 100) [DiscountAmount]
		,[ProductStandardCost]
		,[TotalProductCost]
		,[SalesAmount] - ([UnitPrice] * 5 / 100) [SalesAmount]
		,[TaxAmt]
		,[Freight]
		,[CarrierTrackingNumber]
		,[CustomerPONumber]
		,CONVERT(DATE, DATEADD(MONTH, 3, [OrderDate])) [OrderDate]
		,CONVERT(DATE, DATEADD(MONTH, 3, [DueDate])) [DueDate]
		,CONVERT(DATE, DATEADD(MONTH, 3, [ShipDate])) [ShipDate]
--INTO	PlayGround.dbo.NewFacts
FROM	FactInternetSales
WHERE	ProductKey IN (214, 217)