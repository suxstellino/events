USE UdfDemo2;
go

CREATE OR ALTER FUNCTION dbo.GetLocation
      (@LocationType       char(1),
       @LocationID         int)
RETURNS varchar(30)
AS
BEGIN;
  DECLARE @Location         varchar(30);

  IF @LocationType       = 'C'
  BEGIN;
    SELECT @Location     = CountryName
    FROM   dbo.Countries
    WHERE  CountryID     = @LocationID;
  END;
  ELSE IF @LocationType  = 'S'
  BEGIN;
    SELECT @Location     = StateName
    FROM   dbo.States
    WHERE  StateID       = @LocationID;
  END;
  ELSE IF @LocationType  = 'A'
  BEGIN;
    SELECT @Location     = AreaName
    FROM   dbo.Areas
    WHERE  AreaID        = @LocationID;
  END;
  ELSE IF @LocationType  = 'R'
  BEGIN;
    SELECT @Location     = RegionName
    FROM   dbo.Regions
    WHERE  RegionID      = @LocationID;
  END;
  ELSE IF @LocationType  = 'O'
  BEGIN;
    SELECT @Location     = ContinentName
    FROM   dbo.Continents
    WHERE  ContinentID   = @LocationID;
  END;

  RETURN @Location;
END;
go


SET STATISTICS IO ON;
go

SELECT     SalesID, LocationType, LocationID,
           dbo.GetLocation(LocationType, LocationID) AS "Location name"
FROM       dbo.Sales
ORDER BY   SalesID;
go

SELECT     SalesRepID, LocationType, LocationID,
           dbo.GetLocation(LocationType, LocationID) AS "Location name"
FROM       dbo.SalesReps
ORDER BY   SalesRepID;
go

SELECT     DirectorID, LocationType, LocationID,
           dbo.GetLocation(LocationType, LocationID) AS "Location name"
FROM       dbo.Directors
ORDER BY   DirectorID;
go

SELECT     BigTableID, LocationType, LocationID,
           dbo.GetLocation(LocationType, LocationID) AS "Location name"
FROM       dbo.BigTable
ORDER BY   BigTableID;
go
