USE master;
go

-- Remove old version of demo database. Use brute force if necessary.
IF EXISTS (SELECT * FROM sys.databases WHERE name = N'UdfDemo2')
  BEGIN;
  ALTER DATABASE UdfDemo2 SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
  DROP DATABASE UdfDemo2;
  END;
go

-- Create the empty demo database, with sufficient size for the demo table.
-- To make the script run on all databases, I don't hardcode the directory,
-- but use the directory where the master database lives;
-- this gives me the guarantee that the directory exists
-- and is accessible by SQL Server.
--
-- Unfortunately, this requires the use of dynamic SQL,
-- which I normally avoid. In this case, though, the risk is acceptable.
-- The only way to exploit this dynamic SQL is to install an instance
-- with the master database in a directory with a carefully crafted pathname;
-- whoever can do that must have admin rights
-- and doesn't need the SQL injection attack.
DECLARE @master_directory nvarchar(260);
SET @master_directory =
 (SELECT REPLACE(physical_name, 'master.mdf', '')
  FROM   sys.database_files
  WHERE  name='master'
  AND    type=0);
EXECUTE
 (N'CREATE DATABASE UdfDemo2
    ON PRIMARY
      (NAME = UdfDemo2,
       FILENAME = ''' + @master_directory + N'UdfDemo2.mdf'',
       SIZE = 150MB,
       FILEGROWTH = 50MB)
    LOG ON
      (NAME = UdfDemo2Log,
       FILENAME = ''' + @master_directory + N'UdfDemo2.ldf'',
       SIZE = 15MB,
       FILEGROWTH = 5MB);');
go

-- Switch to tempdb before switching to IndexDemo.
-- If IndexDemo was not created, the USE statement fails,
-- but the next batch will still execute.
-- Switching to tempdb first ensures spurious tables will be created there.

USE tempdb;
go
USE UdfDemo2;
go

-- Set compatibility level to SQL Server 2016
ALTER DATABASE UdfDemo2 SET COMPATIBILITY_LEVEL = 130;

SET NOCOUNT ON;

-- Create tables for various geographic entities,
-- and load them with some sample data

-- "Real" geographic entities: contintents, countries, states

CREATE TABLE Continents
       (ContinentID              int               NOT NULL,
        ContinentName            varchar(30)       NOT NULL,
     -- Other columns,
        CONSTRAINT PK_Continents PRIMARY KEY      (ContinentID)
       );
INSERT INTO Continents (ContinentID, ContinentName)
VALUES (1, 'Africa'),
       (2, 'Asia'),
       (3, 'Australia'),
       (4, 'Europe'),
       (5, 'North America'),
       (6, 'South America');
go

CREATE TABLE Countries
       (CountryID                int               NOT NULL,
        CountryName              varchar(30)       NOT NULL,
     -- Other columns,
        CONSTRAINT PK_Countries  PRIMARY KEY      (CountryID)
       );
INSERT INTO Countries (CountryID, CountryName)
VALUES (1, 'Denmark'),
       (2, 'United States of America'),
       (3, 'the Netherlands'),
       (4, 'Belgium'),
       (5, 'China'),
       (6, 'Sweden');
go

CREATE TABLE States
       (StateID                  int               NOT NULL,
        StateName                varchar(30)       NOT NULL,
     -- Other columns,
        CONSTRAINT PK_States     PRIMARY KEY      (StateID)
       );
INSERT INTO States (StateID, StateName)
VALUES (1, 'Washington'),
       (2, 'Mississippi'),
       (3, 'New York'),
       (4, 'Texas'),
       (5, 'Nebraska'),
       (6, 'Kentucky');
go

-- "Proprietary" entities: Areas and regions (Regions are multiple states or multiple (small) countries; areas are much larger).

CREATE TABLE Areas
       (AreaID                   int               NOT NULL,
        AreaName                 varchar(30)       NOT NULL,
     -- Other columns,
        CONSTRAINT PK_Areas      PRIMARY KEY      (AreaID)
       );
INSERT INTO Areas (AreaID, AreaName)
VALUES (1, 'Americas'),
       (2, 'Europe, Middle East, & Africa'),
       (3, 'Pacific');
go

CREATE TABLE Regions
       (RegionID                 int               NOT NULL,
        RegionName               varchar(30)       NOT NULL,
     -- Other columns,
        CONSTRAINT PK_Regions    PRIMARY KEY      (RegionID)
       );
INSERT INTO Regions (RegionID, RegionName)
VALUES (1, 'European Union'),
       (2, 'Greater China'),
       (3, 'North West USA'),
       (4, 'South West USA');
go

-- Create tables that "reference" the preceding tables

-- Sales are always at the lowest level: state or country
CREATE TABLE Sales
       (SalesID                  int               NOT NULL,   -- Not a very good key
        LocationType             char(1)           NOT NULL,
        LocationID               int               NOT NULL,
     -- Other columns,
        CONSTRAINT PK_Sales      PRIMARY KEY      (SalesID),
        CONSTRAINT CK_Sales_Location
                                 CHECK (LocationType IN ('C','S'))  -- Country or State
       );
INSERT INTO Sales (SalesID, LocationType, LocationID)
VALUES (1, 'C', 1),    -- Denmark has no states, so use Country
       (2, 'S', 1);    -- America has states, so use State (Washington, in this case)
go

-- Sales reps can work at various levels, depending on how active the company is in various parts of the world
CREATE TABLE SalesReps
       (SalesRepID               int               NOT NULL,
        LocationType             char(1)           NOT NULL,
        LocationID               int               NOT NULL,
     -- Other columns,
        CONSTRAINT PK_SalesReps  PRIMARY KEY      (SalesRepID),
        CONSTRAINT CK_SalesReps_Location
                                 CHECK (LocationType IN ('C','S','A','R'))  -- Country, State, Area, Region
       );
INSERT INTO SalesReps (SalesRepID, LocationType, LocationID)
VALUES (1, 'R', 3),    -- North West USA
       (2, 'S', 6),    -- Kentucky
       (3, 'A', 3),    -- Pacific
       (4, 'C', 6);    -- Sweden
go

-- Directors are responsible for areas, regions, or continents
CREATE TABLE Directors
       (DirectorID               int               NOT NULL,
        LocationType             char(1)           NOT NULL,
        LocationID               int               NOT NULL,
     -- Other columns,
        CONSTRAINT PK_Directors  PRIMARY KEY      (DirectorID),
        CONSTRAINT CK_Directors_Location
                                 CHECK (LocationType IN ('A','R','O'))  -- Area, Region, cOntinent (sorry!)
       );
INSERT INTO Directors (DirectorID, LocationType, LocationID)
VALUES (1, 'A', 2),    -- EMEA
       (2, 'R', 2),    -- Greater China
       (3, 'O', 3);    -- Australia
go


-- For performance test, we'll fill a big table with random values;
-- to make this easier, we also add areas and regions to have six rows in each table.
INSERT INTO Regions (RegionID, RegionName)
VALUES (5, 'Region 5'),
       (6, 'Region 6');
INSERT INTO Areas (AreaID, AreaName)
VALUES (4, 'Area 4'),
       (5, 'Area 5'),
       (6, 'Area 6');
go

CREATE TABLE dbo.BigTable
       (BigTableID               int               NOT NULL,
        LocationType             char(1)           NOT NULL,
        LocationID               int               NOT NULL,
        CONSTRAINT PK_BigTable   PRIMARY KEY      (BigTableID),
        CONSTRAINT CK_BigTable_Location
                                 CHECK (LocationType IN ('C','S','A','R','O'))
       );

DECLARE @rpt int = 1, @Type char(1), @ID int;
WHILE @rpt <= 10000
BEGIN;
  SET @Type = SUBSTRING ('CSARO', CAST(RAND() * 5 AS int) + 1, 1);
  SET @ID = RAND() * 6 + 1;
  INSERT INTO dbo.BigTable (BigTableID, LocationType, LocationID)
  VALUES (@rpt, @Type, @ID);
  SET @rpt += 1;
END;
