USE UdfDemo;
go

CREATE OR ALTER FUNCTION dbo.GetAllProjectedWages
       (@HoursPerYear      int,
        @FactorSalesPerson decimal(5,3),
        @FactorCommission  decimal(5,3),
        @FactorSalesYTD    decimal(5,3),
        @FactorSalaried1   decimal(5,3),
        @FactorSalaried0   decimal(5,3))
RETURNS @ProjectedWages    TABLE (BusinessEntityID int          NOT NULL PRIMARY KEY,
                                  JobTitle         nvarchar(50) NOT NULL,
                                  Title            nvarchar(8)  NULL,
                                  FirstName        nvarchar(50) NOT NULL,
                                  LastName         nvarchar(50) NOT NULL,
                                  ProjectedWage    money        NOT NULL)
AS
BEGIN;
  WITH EmployeePayRanked
  AS (SELECT  BusinessEntityID, Rate,
              RANK() OVER (PARTITION BY BusinessEntityID ORDER BY RateChangeDate DESC) AS rn
      FROM    dbo.EmployeePayHistory)
  INSERT INTO @ProjectedWages (BusinessEntityID, JobTitle, Title, FirstName, LastName, ProjectedWage)
  SELECT      e.BusinessEntityID, e.JobTitle,
              p.Title, p.FirstName, p.LastName,
              CAST(CASE
                     WHEN sp.BusinessEntityID IS NOT NULL
                       THEN @HoursPerYear * (ep.Rate * @FactorSalesPerson)
                         + (sp.CommissionPct * @FactorCommission) * (sp.SalesYTD * @FactorSalesYTD)
                     WHEN e.SalariedFlag = 1
                       THEN @HoursPerYear * (ep.Rate * @FactorSalaried1)
                       ELSE @HoursPerYear * (ep.Rate * @FactorSalaried0)
                   END AS money)
  FROM        dbo.Employee         AS e
  INNER JOIN  dbo.Person            AS p
	    ON    p.BusinessEntityID     = e.BusinessEntityID
  INNER JOIN  EmployeePayRanked    AS ep
        ON    ep.BusinessEntityID   = e.BusinessEntityID
        AND   ep.rn                 = 1
  LEFT  JOIN  dbo.SalesPerson      AS sp
        ON    sp.BusinessEntityID   = e.BusinessEntityID;

  RETURN;
END;
go




SET STATISTICS IO ON;
go

SELECT     w.BusinessEntityID, w.JobTitle,
           CONCAT(w.Title + ' ', w.FirstName + ' ', w.LastName) AS FullName,
           w.ProjectedWage
FROM       dbo.GetAllProjectedWages(1800, 0.75, 1.25, 1.5, 1, 1.03) AS w
ORDER BY   w.BusinessEntityID;
go


SELECT     SUM(w.ProjectedWage) AS "Total Projected Wage"
FROM       dbo.GetAllProjectedWages(1800, 0.75, 1.25, 1.5, 1, 1.03) AS w;
go




SELECT     ed.DepartmentID,
           SUM(w.ProjectedWage) AS "Projected Wage"
FROM       dbo.GetAllProjectedWages(1800, 0.75, 1.25, 1.5, 1, 1.03) AS w
INNER JOIN dbo.EmployeeDepartmentHistory AS ed
      ON   ed.BusinessEntityID = w.BusinessEntityID
      AND  ed.EndDate IS NULL
GROUP BY   ed.DepartmentID
ORDER BY   ed.DepartmentID;
go



DECLARE @BusinessEntityID int = 1234;

SELECT     w.BusinessEntityID, w.JobTitle,
           CONCAT(w.Title + ' ', w.FirstName + ' ', w.LastName) AS FullName,
           w.ProjectedWage
FROM       dbo.GetAllProjectedWages(1800, 0.75, 1.25, 1.5, 1, 1.03) AS w
WHERE      w.BusinessEntityID    = @BusinessEntityID;
go
