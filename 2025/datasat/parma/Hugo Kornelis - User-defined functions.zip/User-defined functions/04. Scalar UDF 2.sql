USE UdfDemo;
go

CREATE OR ALTER FUNCTION dbo.GetProjectedCommission2
      (@CommissionPct     decimal(7,4),
       @SalesYTD          money,
       @FactorCommission  decimal(5,3),
       @FactorSalesYTD    decimal(5,3))
RETURNS money
AS
BEGIN;
  DECLARE @ProjectedCommission money;

  SET @ProjectedCommission = (@CommissionPct * @FactorCommission) * (@SalesYTD * @FactorSalesYTD);
  RETURN @ProjectedCommission;
END;
go

CREATE OR ALTER FUNCTION dbo.GetProjectedWage2
      (@SalariedFlag      bit,
       @Rate              money,
       @IsSalesPerson     bit,
       @CommissionPct     decimal(7,4),
       @SalesYTD          money,
       @HoursPerYear      int,
       @FactorSalesPerson decimal(5,3),
       @FactorCommission  decimal(5,3),
       @FactorSalesYTD    decimal(5,3),
       @FactorSalaried1   decimal(5,3),
       @FactorSalaried0   decimal(5,3))
RETURNS money
AS
BEGIN;
  DECLARE @ProjectedWage money;

  -- Calculate projected wage, by type:
  IF @IsSalesPerson = 1
    BEGIN;
    SET @ProjectedWage = @HoursPerYear * (@Rate * @FactorSalesPerson)
                       + dbo.GetProjectedCommission2(@CommissionPct, @SalesYTD, @FactorCommission, @FactorSalesYTD);
    END;
  ELSE IF @SalariedFlag = 1
    BEGIN;
    SET @ProjectedWage = @HoursPerYear * (@Rate * @FactorSalaried1);
    END;
  ELSE
    BEGIN;
    SET @ProjectedWage = @HoursPerYear * (@Rate * @FactorSalaried0);
    END;
  RETURN @ProjectedWage;
END;
go



SET STATISTICS IO ON;
go

WITH EmployeePayRanked
AS (SELECT BusinessEntityID, Rate,
           RANK() OVER (PARTITION BY BusinessEntityID ORDER BY RateChangeDate DESC) AS rn
    FROM   dbo.EmployeePayHistory)
SELECT     e.BusinessEntityID, e.JobTitle,
           CONCAT(p.Title + ' ', p.FirstName + ' ', p.LastName) AS FullName,
           dbo.GetProjectedWage2(e.SalariedFlag, ep.Rate, CASE WHEN sp.BusinessEntityID IS NOT NULL THEN 1 ELSE 0 END, sp.CommissionPct, sp.SalesYTD,
                                 1800, 0.75, 1.25, 1.5, 1, 1.03) AS "Projected Wage"
FROM       dbo.Employee         AS e
INNER JOIN dbo.Person           AS p
	  ON   p.BusinessEntityID    = e.BusinessEntityID
INNER JOIN EmployeePayRanked    AS ep
      ON   ep.BusinessEntityID   = e.BusinessEntityID
      AND  ep.rn                 = 1
LEFT  JOIN dbo.SalesPerson      AS sp
      ON   sp.BusinessEntityID   = e.BusinessEntityID
ORDER BY   BusinessEntityID;
go



WITH EmployeePayRanked
AS (SELECT BusinessEntityID, Rate,
           RANK() OVER (PARTITION BY BusinessEntityID ORDER BY RateChangeDate DESC) AS rn
    FROM   dbo.EmployeePayHistory)
SELECT     SUM(dbo.GetProjectedWage2(e.SalariedFlag, ep.Rate, CASE WHEN sp.BusinessEntityID IS NOT NULL THEN 1 ELSE 0 END, sp.CommissionPct, sp.SalesYTD,
                                     1800, 0.75, 1.25, 1.5, 1, 1.03)) AS "Total Projected Wage"
FROM       dbo.Employee         AS e
INNER JOIN EmployeePayRanked    AS ep
      ON   ep.BusinessEntityID   = e.BusinessEntityID
      AND  ep.rn                 = 1
LEFT  JOIN dbo.SalesPerson      AS sp
      ON   sp.BusinessEntityID   = e.BusinessEntityID
go




WITH EmployeePayRanked
AS (SELECT BusinessEntityID, Rate,
           RANK() OVER (PARTITION BY BusinessEntityID ORDER BY RateChangeDate DESC) AS rn
    FROM   dbo.EmployeePayHistory)
SELECT     ed.DepartmentID,
           SUM(dbo.GetProjectedWage2(e.SalariedFlag, ep.Rate, CASE WHEN sp.BusinessEntityID IS NOT NULL THEN 1 ELSE 0 END, sp.CommissionPct, sp.SalesYTD,
                                     1800, 0.75, 1.25, 1.5, 1, 1.03)) AS "Projected Wage"
FROM       dbo.Employee         AS e
INNER JOIN dbo.Person           AS p
	  ON   p.BusinessEntityID    = e.BusinessEntityID
INNER JOIN EmployeePayRanked    AS ep
      ON   ep.BusinessEntityID   = e.BusinessEntityID
      AND  ep.rn                 = 1
LEFT  JOIN dbo.SalesPerson      AS sp
      ON   sp.BusinessEntityID   = e.BusinessEntityID
INNER JOIN dbo.EmployeeDepartmentHistory AS ed
      ON   ed.BusinessEntityID   = e.BusinessEntityID
      AND  ed.EndDate           IS NULL
GROUP BY   ed.DepartmentID
ORDER BY   ed.DepartmentID;
go




DECLARE @BusinessEntityID int = 1234;

WITH EmployeePayRanked
AS (SELECT BusinessEntityID, Rate,
           RANK() OVER (PARTITION BY BusinessEntityID ORDER BY RateChangeDate DESC) AS rn
    FROM   dbo.EmployeePayHistory)
SELECT     e.JobTitle,
           CONCAT(p.Title + ' ', p.FirstName + ' ', p.LastName) AS FullName,
           dbo.GetProjectedWage2(e.SalariedFlag, ep.Rate, CASE WHEN sp.BusinessEntityID IS NOT NULL THEN 1 ELSE 0 END, sp.CommissionPct, sp.SalesYTD,
                                 1800, 0.75, 1.25, 1.5, 1, 1.03) AS "Projected Wage"
FROM       dbo.Employee         AS e
INNER JOIN dbo.Person           AS p
	  ON   p.BusinessEntityID    = e.BusinessEntityID
INNER JOIN EmployeePayRanked    AS ep
      ON   ep.BusinessEntityID   = e.BusinessEntityID
      AND  ep.rn                 = 1
LEFT  JOIN dbo.SalesPerson      AS sp
      ON   sp.BusinessEntityID   = e.BusinessEntityID
WHERE      e.BusinessEntityID    = @BusinessEntityID;
go
