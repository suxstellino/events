USE UdfDemo2;
go

CREATE OR ALTER FUNCTION dbo.GetLocationInline
      (@LocationType       char(1),
       @LocationID         int)
RETURNS TABLE
AS
RETURN
 (SELECT     COALESCE (c.CountryName, s.StateName, a.AreaName,
                       r.RegionName, o.ContinentName) AS LocationName
  FROM      (SELECT @LocationType, @LocationID) AS i(LocationType, LocationID)
  LEFT  JOIN dbo.Countries  AS  c
        ON   c.CountryID     =  i.LocationID
        AND  i.LocationType  = 'C'
  LEFT  JOIN dbo.States     AS  s
        ON   s.StateID       =  i.LocationID
        AND  i.LocationType  = 'S'
  LEFT  JOIN dbo.Areas      AS  a
        ON   a.AreaID        =  i.LocationID
        AND  i.LocationType  = 'A'
  LEFT  JOIN dbo.Regions    AS  r
        ON   r.RegionID      =  i.LocationID
        AND  i.LocationType  = 'R'
  LEFT  JOIN dbo.Continents AS  o
        ON   o.ContinentID   =  i.LocationID
        AND  i.LocationType  = 'O');
go


-- Test
SELECT *
FROM   dbo.GetLocationInline ('C', 1);
go


-- Will not work
SELECT      s.SalesID, s.LocationType, s.LocationID,
            l.LocationName AS "Location name"
FROM        dbo.Sales AS s
CROSS JOIN  dbo.GetLocationInline (s.LocationType, s.LocationID) AS l
ORDER BY    s.SalesID;
go



-- Will work
SELECT      s.SalesID, s.LocationType, s.LocationID,
            l.LocationName AS "Location name"
FROM        dbo.Sales AS s
CROSS APPLY dbo.GetLocationInline (s.LocationType, s.LocationID) AS l
ORDER BY    s.SalesID;
go






SET STATISTICS IO ON;
go

SELECT      s.SalesID, s.LocationType, s.LocationID,
            l.LocationName AS "Location name"
FROM        dbo.Sales AS s
CROSS APPLY dbo.GetLocationInline (s.LocationType, s.LocationID) AS l
ORDER BY    s.SalesID;
go

SELECT      r.SalesRepID, r.LocationType, r.LocationID,
            l.LocationName AS "Location name"
FROM        dbo.SalesReps AS r
CROSS APPLY dbo.GetLocationInline (r.LocationType, r.LocationID) AS l
ORDER BY    r.SalesRepID;
go

SELECT      d.DirectorID, d.LocationType, d.LocationID,
            l.LocationName AS "Location name"
FROM        dbo.Directors AS d
CROSS APPLY dbo.GetLocationInline (d.LocationType, d.LocationID) AS l
ORDER BY    d.DirectorID;
go

SELECT      b.BigTableID, b.LocationType, b.LocationID,
            l.LocationName AS "Location name"
FROM        dbo.BigTable AS b
CROSS APPLY dbo.GetLocationInline (b.LocationType, b.LocationID) AS l
ORDER BY    b.BigTableID;
go
